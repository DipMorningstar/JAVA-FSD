public class arraydemo {

public static void main(String[] args) {
int x[]= {40,50,60,70,80,90};
for(int i=0;i<=5;i++) {
System.out.println("Elements of array : "+x[i]);
}
int[][] y = {
            {2,4 , 6, 8}, 
            {3,6,9} };
      
      System.out.println("Length of row 1: " + y[0].length);
      }
}
