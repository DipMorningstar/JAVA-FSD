import java.util.*;
public class typeCasting {

	public static void main(String[] args) {
		
		//implicit conversion
		System.out.println("Implicit Type Casting");
		char a='A';
		System.out.println("Value of a: "+a);
		
		int m=n;
		System.out.println("Value of m: "+m);
		
		float b=a;
		System.out.println("Value of a: "+a);
		
		long p=q;
		System.out.println("Value of p: "+p);
		
		double s=t;
		System.out.println("Value of s: "+s);
		System.out.println("\n");
		System.out.println("Explicit Type Casting");
		double x=30.5;
		int y=(int)x;
		System.out.println("Value of x: "+x);
		System.out.println("Value of y: "+y);
		
	}
}

